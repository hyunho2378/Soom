# PROGRESS.md — 진행 상태

## 완료
- 기반 앱: Express 정적 + ws 시그널링 + WebRTC P2P 화면 공유(발표자 교체 자동 처리, 참가자 패널). 기존 코드 유지, 손대지 않음.
- 실습 기록물 기능 추가
  - server.js: /api/items, /api/records(multer 이미지 업로드), /api/records/reset. roomRecords Map + data/records.json 영속화. 라벨·트랙은 서버 정본(PRACTICE_ITEMS)에서만 판단. 방별 WS 브로드캐스트(records-init / record-added / records-reset).
  - index.html: 회의실 탭(실시간 화면 / 실습 기록물), 올리기 폼, 커스텀 항목 드롭다운, 이미지 첨부·미리보기, 카드 목록, 라이트박스, 초기화 모달.
  - style.css: 주황 토큰 3종 + 탭·폼·드롭다운·카드(트랙 액센트)·썸네일·라이트박스·모달. 반응형 유지.
  - app.js: 탭 전환, 드롭다운, 첨부 미리보기, 업로드 POST, WS 실시간 카드, 초기화 모달, 라이트박스.
  - package.json: multer ^2.0.1(2.2.0 설치, 1.x 취약점 회피). .gitignore: uploads/ data/.

## 검증 완료(실행 기준)
- server.js / app.js node --check 통과.
- GET /api/items 17개 항목·라벨·트랙 정확.
- POST /api/records: 정상 200, 이미지 uploads/ 저장 후 /uploads/로 byte 동일 서빙(200), 잘못된 itemCode 400, 요약·이미지 둘 다 없음 400, 비이미지 파일 필터로 0장 저장.
- data/records.json 저장·재로드 정상.
- reset: 확인 문구 불일치 400, 일치 시 레코드 비우고 이미지 파일 삭제.
- WS: 기존 참가자 record-added 실시간 수신, 입장 시 records-init 수신, 뒤늦은 입장자 기존 기록 로드, reset 브로드캐스트 수신. 시그널링과 충돌 없음.

## 선택 개선(미적용, 제안)
- 영속화 강화: 무료 플랜 디스크 휘발 대응. SQLite(better-sqlite3) 또는 Render Persistent Disk 유료 옵션. 현재는 JSON 파일이라 재배포 시 소실 가능.
- 막힌 네트워크: 화면이 안 뜨면 app.js ICE_SERVERS에 무료 TURN 추가.
- 이미지 용량 관리: 다수 업로드 누적 시 디스크 정리 정책 필요.

## 수정 이력
- app.js renderAllRecords: reverse 누락으로 입장 시(records-init) 오래된 순, 실시간(record-added) 최신 순이라 정렬이 섞이던 버그 수정. list.slice().reverse()로 두 경로 모두 최신 위 통일.
