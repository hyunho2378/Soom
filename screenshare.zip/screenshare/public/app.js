// 동해 AI 교육용 실시간 화면 공유 도구 — 클라이언트

// ICE 서버 설정. 기본은 구글 무료 STUN만 사용한다.
// 회사·기관 와이파이처럼 막힌 네트워크에서 화면이 안 뜨면,
// 무료 TURN 서버(Metered, OpenRelay 등)에 가입해 아래 배열에 추가한다.
// 예: { urls: "turn:openrelay.metered.ca:80", username: "...", credential: "..." }
const ICE_SERVERS = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" },
  // 여기에 TURN 서버를 추가할 수 있다.
];

function randomId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function avatarColor(name) {
  const palette = ["#0053F0", "#FF6B35", "#16A34A", "#7C3AED", "#DB2777", "#0891B2"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return palette[Math.abs(hash) % palette.length];
}

const myId = randomId();
let myName = "";
let myRoom = "";
let ws = null;
let isBroadcaster = false;
let localStream = null;
const peerConnections = {}; // remoteId -> RTCPeerConnection (내가 발표자일 때 여러 개)
let viewerPc = null; // 내가 시청자일 때 발표자와의 연결 하나

const joinScreen = document.getElementById("joinScreen");
const roomScreen = document.getElementById("roomScreen");
const roomInput = document.getElementById("roomInput");
const nameInput = document.getElementById("nameInput");
const joinBtn = document.getElementById("joinBtn");
const joinHint = document.getElementById("joinHint");
const roomNameLabel = document.getElementById("roomNameLabel");
const participantCount = document.getElementById("participantCount");
const participantList = document.getElementById("participantList");
const leaveBtn = document.getElementById("leaveBtn");
const shareBtn = document.getElementById("shareBtn");
const shareStatus = document.getElementById("shareStatus");
const remoteVideo = document.getElementById("remoteVideo");
const viewerPlaceholder = document.getElementById("viewerPlaceholder");
const presenterBadge = document.getElementById("presenterBadge");

joinBtn.addEventListener("click", join);
[roomInput, nameInput].forEach((el) => {
  el.addEventListener("keydown", (e) => {
    if (e.key === "Enter") join();
  });
});

function join() {
  const room = roomInput.value.trim();
  const name = nameInput.value.trim();
  if (!room || !name) {
    joinHint.textContent = "방 이름과 내 이름을 모두 입력하세요.";
    return;
  }
  myRoom = room;
  myName = name;
  joinBtn.disabled = true;
  joinHint.textContent = "";

  const proto = location.protocol === "https:" ? "wss" : "ws";
  ws = new WebSocket(`${proto}://${location.host}`);

  ws.addEventListener("open", () => {
    ws.send(JSON.stringify({ type: "join", id: myId, room: myRoom, name: myName }));
    joinScreen.classList.add("hidden");
    roomScreen.classList.remove("hidden");
    roomNameLabel.textContent = myRoom;
    setupRecords(); // 기록물 UI 초기화
  });

  ws.addEventListener("message", (evt) => {
    const msg = JSON.parse(evt.data);
    handleMessage(msg);
  });

  ws.addEventListener("close", () => {
    if (!joinScreen.classList.contains("hidden")) return;
    shareStatus.textContent = "연결이 끊어졌습니다. 페이지를 새로고침하세요.";
  });

  ws.addEventListener("error", () => {
    joinBtn.disabled = false;
    joinHint.textContent = "연결에 실패했습니다. 잠시 후 다시 시도하세요.";
  });
}

function handleMessage(msg) {
  switch (msg.type) {
    case "participants":
      renderParticipants(msg.list, msg.broadcasterId);
      break;
    case "broadcaster-changed":
      onBroadcasterChanged(msg.broadcasterId, msg.name);
      break;
    case "you-are-broadcaster":
      startBroadcastingTo(msg.viewerIds);
      break;
    case "new-viewer":
      if (isBroadcaster && localStream) {
        connectToViewer(msg.id);
      }
      break;
    case "offer":
      handleOffer(msg.from, msg.sdp);
      break;
    case "answer":
      handleAnswer(msg.from, msg.sdp);
      break;
    case "ice":
      handleIce(msg.from, msg.candidate);
      break;
    case "force-stop-share":
      stopSharing(false);
      break;
    case "records-init":
      renderAllRecords(msg.list || []);
      break;
    case "record-added":
      addRecordCard(msg.record, true);
      break;
    case "records-reset":
      renderAllRecords([]);
      break;
  }
}

function renderParticipants(list, broadcasterId) {
  participantCount.textContent = `참가자 ${list.length}명`;
  participantList.innerHTML = list
    .map((p) => {
      const initial = p.name.slice(0, 1).toUpperCase();
      const presenting = p.id === broadcasterId;
      return `
        <li class="participant-item ${presenting ? "is-presenting" : ""}">
          <span class="avatar" style="background:${avatarColor(p.name)}">${escapeHtml(initial)}</span>
          <span class="p-name">${escapeHtml(p.name)}${p.id === myId ? " (나)" : ""}</span>
          ${presenting ? '<span class="p-tag">발표중</span>' : ""}
        </li>`;
    })
    .join("");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function onBroadcasterChanged(broadcasterId, name) {
  if (broadcasterId === myId) return; // 내가 발표자면 별도 처리 안 함

  // 이전 시청 연결 정리
  if (viewerPc) {
    viewerPc.close();
    viewerPc = null;
  }
  remoteVideo.srcObject = null;

  if (!broadcasterId) {
    viewerPlaceholder.classList.remove("hidden");
    presenterBadge.classList.add("hidden");
    shareStatus.textContent = "";
  } else {
    viewerPlaceholder.classList.add("hidden");
    presenterBadge.classList.remove("hidden");
    presenterBadge.textContent = `${name} 님이 발표 중`;
    shareStatus.textContent = `${name} 님의 화면을 보고 있습니다.`;
  }
}

// ── 발표자 쪽 로직 ──
shareBtn.addEventListener("click", async () => {
  if (isBroadcaster) {
    stopSharing(true);
    return;
  }
  try {
    localStream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 10 },
      audio: false,
    });
  } catch (e) {
    shareStatus.textContent = "화면 공유가 취소되었습니다.";
    return;
  }

  isBroadcaster = true;
  shareBtn.textContent = "공유 중지";
  shareBtn.classList.add("active");
  shareStatus.textContent = "내 화면을 공유하고 있습니다.";
  viewerPlaceholder.classList.add("hidden");
  presenterBadge.classList.remove("hidden");
  presenterBadge.textContent = "나의 화면 공유 중";
  remoteVideo.srcObject = localStream;

  localStream.getVideoTracks()[0].addEventListener("ended", () => {
    stopSharing(true);
  });

  ws.send(JSON.stringify({ type: "start-share" }));
});

function startBroadcastingTo(viewerIds) {
  viewerIds.forEach((id) => connectToViewer(id));
}

function connectToViewer(viewerId) {
  if (peerConnections[viewerId]) return;
  const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
  peerConnections[viewerId] = pc;

  localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));

  pc.onicecandidate = (e) => {
    if (e.candidate) {
      ws.send(JSON.stringify({ type: "ice", to: viewerId, candidate: e.candidate }));
    }
  };

  pc.createOffer()
    .then((offer) => pc.setLocalDescription(offer))
    .then(() => {
      ws.send(JSON.stringify({ type: "offer", to: viewerId, sdp: pc.localDescription }));
    });
}

function handleAnswer(fromId, sdp) {
  const pc = peerConnections[fromId];
  if (pc) pc.setRemoteDescription(new RTCSessionDescription(sdp));
}

function stopSharing(notifyServer) {
  isBroadcaster = false;
  if (localStream) {
    localStream.getTracks().forEach((t) => t.stop());
    localStream = null;
  }
  Object.values(peerConnections).forEach((pc) => pc.close());
  Object.keys(peerConnections).forEach((k) => delete peerConnections[k]);

  shareBtn.textContent = "내 화면 공유하기";
  shareBtn.classList.remove("active");
  shareStatus.textContent = "";
  remoteVideo.srcObject = null;
  viewerPlaceholder.classList.remove("hidden");
  presenterBadge.classList.add("hidden");

  if (notifyServer && ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "stop-share" }));
  }
}

// ── 시청자 쪽 로직 ──
function handleOffer(fromId, sdp) {
  if (viewerPc) {
    viewerPc.close();
    viewerPc = null;
  }
  const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
  viewerPc = pc;

  pc.ontrack = (e) => {
    remoteVideo.srcObject = e.streams[0];
    viewerPlaceholder.classList.add("hidden");
  };

  pc.onicecandidate = (e) => {
    if (e.candidate) {
      ws.send(JSON.stringify({ type: "ice", to: fromId, candidate: e.candidate }));
    }
  };

  pc.setRemoteDescription(new RTCSessionDescription(sdp))
    .then(() => pc.createAnswer())
    .then((answer) => pc.setLocalDescription(answer))
    .then(() => {
      ws.send(JSON.stringify({ type: "answer", to: fromId, sdp: pc.localDescription }));
    });
}

function handleIce(fromId, candidate) {
  const pc = isBroadcaster ? peerConnections[fromId] : viewerPc;
  if (pc) pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
}

// ── 나가기 ──
leaveBtn.addEventListener("click", () => {
  window.location.reload();
});

window.addEventListener("beforeunload", () => {
  if (isBroadcaster) stopSharing(true);
});

// ══════════ 실습 기록물 ══════════

const tabLive = document.getElementById("tabLive");
const tabRecords = document.getElementById("tabRecords");
const panelLive = document.getElementById("panelLive");
const panelRecords = document.getElementById("panelRecords");
const recordsBadge = document.getElementById("recordsBadge");
const recordAuthor = document.getElementById("recordAuthor");
const itemTrigger = document.getElementById("itemTrigger");
const itemTriggerLabel = document.getElementById("itemTriggerLabel");
const itemPanel = document.getElementById("itemPanel");
const summaryInput = document.getElementById("summaryInput");
const attachBtn = document.getElementById("attachBtn");
const imageInput = document.getElementById("imageInput");
const previewList = document.getElementById("previewList");
const submitRecordBtn = document.getElementById("submitRecordBtn");
const recordStatus = document.getElementById("recordStatus");
const recordsList = document.getElementById("recordsList");
const recordsEmpty = document.getElementById("recordsEmpty");
const resetRecordsBtn = document.getElementById("resetRecordsBtn");
const resetModal = document.getElementById("resetModal");
const resetConfirmInput = document.getElementById("resetConfirmInput");
const resetConfirmBtn = document.getElementById("resetConfirmBtn");
const resetCancelBtn = document.getElementById("resetCancelBtn");
const resetStatus = document.getElementById("resetStatus");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const lightboxClose = document.getElementById("lightboxClose");

let selectedItemCode = "";
let selectedFiles = []; // File[] (첨부 대기 목록)
let recordsSetup = false;

// 입장 후 한 번만 초기화한다.
function setupRecords() {
  if (recordsSetup) return;
  recordsSetup = true;
  recordAuthor.textContent = myName;
  loadItems();
}

// 탭 전환. 영상은 background에서 계속 재생되므로 뷰어는 그대로 유지된다.
function switchTab(tab) {
  const live = tab === "live";
  tabLive.classList.toggle("is-active", live);
  tabRecords.classList.toggle("is-active", !live);
  tabLive.setAttribute("aria-selected", String(live));
  tabRecords.setAttribute("aria-selected", String(!live));
  panelLive.classList.toggle("hidden", !live);
  panelRecords.classList.toggle("hidden", live);
}
tabLive.addEventListener("click", () => switchTab("live"));
tabRecords.addEventListener("click", () => switchTab("records"));

// 실습 항목 정본을 받아 드롭다운을 만든다.
async function loadItems() {
  try {
    const res = await fetch("/api/items");
    const items = await res.json();
    buildDropdown(items);
  } catch (e) {
    itemTriggerLabel.textContent = "항목을 불러오지 못했습니다";
  }
}

function buildDropdown(items) {
  const groups = { A: [], B: [] };
  items.forEach((it) => groups[it.track] && groups[it.track].push(it));
  const section = (track, title) => {
    if (!groups[track].length) return "";
    const opts = groups[track]
      .map(
        (it) => `
        <button type="button" class="dropdown-option" data-code="${it.code}">
          <span class="track-dot ${track.toLowerCase()}"></span>
          <span>${escapeHtml(it.label)}</span>
        </button>`
      )
      .join("");
    return `<div class="dropdown-group-label">${title}</div>${opts}`;
  };
  itemPanel.innerHTML = section("A", "트랙 A 기초") + section("B", "트랙 B 심화");

  itemPanel.querySelectorAll(".dropdown-option").forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedItemCode = btn.dataset.code;
      itemTriggerLabel.textContent = btn.querySelector("span:last-child").textContent;
      itemTriggerLabel.classList.remove("dropdown-placeholder");
      itemPanel.querySelectorAll(".dropdown-option").forEach((o) => o.classList.remove("is-selected"));
      btn.classList.add("is-selected");
      closeDropdown();
    });
  });
}

function openDropdown() {
  itemPanel.classList.remove("hidden");
  itemTrigger.setAttribute("aria-expanded", "true");
}
function closeDropdown() {
  itemPanel.classList.add("hidden");
  itemTrigger.setAttribute("aria-expanded", "false");
}
itemTrigger.addEventListener("click", (e) => {
  e.stopPropagation();
  itemPanel.classList.contains("hidden") ? openDropdown() : closeDropdown();
});
document.addEventListener("click", (e) => {
  if (!e.target.closest("#itemDropdown")) closeDropdown();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeDropdown();
    if (!lightbox.classList.contains("hidden")) closeLightbox();
  }
});

// 이미지 첨부 + 미리보기
attachBtn.addEventListener("click", () => imageInput.click());
imageInput.addEventListener("change", () => {
  const incoming = Array.from(imageInput.files);
  incoming.forEach((f) => {
    if (selectedFiles.length >= 10) return;
    selectedFiles.push(f);
  });
  imageInput.value = ""; // 같은 파일 다시 선택 가능하게
  renderPreviews();
});

function renderPreviews() {
  previewList.innerHTML = "";
  selectedFiles.forEach((file, idx) => {
    const url = URL.createObjectURL(file);
    const thumb = document.createElement("div");
    thumb.className = "preview-thumb";
    thumb.innerHTML = `<img src="${url}" alt="첨부 미리보기"><button type="button" class="preview-remove" aria-label="첨부 삭제">×</button>`;
    thumb.querySelector(".preview-remove").addEventListener("click", () => {
      selectedFiles.splice(idx, 1);
      URL.revokeObjectURL(url);
      renderPreviews();
    });
    previewList.appendChild(thumb);
  });
}

// 기록물 올리기
submitRecordBtn.addEventListener("click", async () => {
  if (!selectedItemCode) {
    setRecordStatus("실습 항목을 선택하세요.", "error");
    return;
  }
  const summary = summaryInput.value.trim();
  if (!summary && selectedFiles.length === 0) {
    setRecordStatus("결과 요약이나 이미지를 하나 이상 올리세요.", "error");
    return;
  }

  const form = new FormData();
  form.append("room", myRoom);
  form.append("name", myName);
  form.append("itemCode", selectedItemCode);
  form.append("summary", summary);
  selectedFiles.forEach((f) => form.append("images", f));

  submitRecordBtn.disabled = true;
  setRecordStatus("올리는 중입니다.", "");
  try {
    const res = await fetch("/api/records", { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      setRecordStatus(data.error || "올리지 못했습니다.", "error");
    } else {
      // 서버가 방 전원에게 record-added를 보내므로 카드는 그쪽에서 그려진다.
      summaryInput.value = "";
      selectedFiles = [];
      renderPreviews();
      setRecordStatus("올렸습니다.", "ok");
    }
  } catch (e) {
    setRecordStatus("올리지 못했습니다. 잠시 후 다시 시도하세요.", "error");
  } finally {
    submitRecordBtn.disabled = false;
  }
});

function setRecordStatus(text, kind) {
  recordStatus.textContent = text;
  recordStatus.className = "record-status" + (kind ? " " + kind : "");
}

// 카드 렌더링
function renderAllRecords(list) {
  recordsList.innerHTML = "";
  // 최신이 위로 오게 역순 렌더(서버는 오래된 순으로 보낸다)
  list.slice().reverse().forEach((r) => addRecordCard(r, false));
  updateRecordsMeta();
}

function addRecordCard(record, prepend) {
  const card = document.createElement("div");
  card.className = "record-card" + (record.track === "B" ? " track-b" : "");

  const images = (record.images || [])
    .map(
      (url) => `<button type="button" class="record-image" data-full="${escapeHtml(url)}"><img src="${escapeHtml(url)}" alt="${escapeHtml(record.itemLabel)} 첨부 이미지"></button>`
    )
    .join("");

  card.innerHTML = `
    <div class="record-card-head">
      <span class="item-badge">${escapeHtml(record.itemLabel)}</span>
      <span class="record-author">${escapeHtml(record.name)}</span>
      <span class="record-time">${formatTime(record.createdAt)}</span>
    </div>
    ${record.summary ? `<p class="record-summary">${escapeHtml(record.summary)}</p>` : ""}
    ${images ? `<div class="record-images">${images}</div>` : ""}
  `;

  card.querySelectorAll(".record-image").forEach((btn) => {
    btn.addEventListener("click", () => openLightbox(btn.dataset.full));
  });

  if (prepend) {
    recordsList.prepend(card);
    bumpBadge();
  } else {
    recordsList.appendChild(card);
  }
  updateRecordsMeta();
}

function updateRecordsMeta() {
  const count = recordsList.children.length;
  recordsEmpty.classList.toggle("hidden", count > 0);
  recordsBadge.textContent = String(count);
  recordsBadge.classList.toggle("hidden", count === 0);
}

// 다른 탭에 있을 때 새 기록물이 오면 배지로 알린다.
function bumpBadge() {
  if (panelRecords.classList.contains("hidden")) {
    recordsBadge.classList.remove("hidden");
  }
}

function formatTime(ts) {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${hh}:${mm}`;
}

// 라이트박스
function openLightbox(url) {
  lightboxImg.src = url;
  lightbox.classList.remove("hidden");
}
function closeLightbox() {
  lightbox.classList.add("hidden");
  lightboxImg.src = "";
}
lightboxClose.addEventListener("click", closeLightbox);
lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) closeLightbox();
});

// 초기화 모달
resetRecordsBtn.addEventListener("click", () => {
  resetConfirmInput.value = "";
  resetConfirmBtn.disabled = true;
  resetStatus.textContent = "";
  resetModal.classList.remove("hidden");
  resetConfirmInput.focus();
});
resetCancelBtn.addEventListener("click", () => resetModal.classList.add("hidden"));
resetModal.addEventListener("click", (e) => {
  if (e.target === resetModal) resetModal.classList.add("hidden");
});
resetConfirmInput.addEventListener("input", () => {
  resetConfirmBtn.disabled = resetConfirmInput.value.trim() !== "초기화";
});
resetConfirmBtn.addEventListener("click", async () => {
  resetConfirmBtn.disabled = true;
  resetStatus.textContent = "초기화하는 중입니다.";
  try {
    const res = await fetch("/api/records/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ room: myRoom, confirm: resetConfirmInput.value.trim() }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      resetStatus.textContent = data.error || "초기화하지 못했습니다.";
      resetConfirmBtn.disabled = false;
    } else {
      // 서버가 records-reset을 방 전원에게 보내 목록을 비운다.
      resetModal.classList.add("hidden");
    }
  } catch (e) {
    resetStatus.textContent = "초기화하지 못했습니다.";
    resetConfirmBtn.disabled = false;
  }
});
